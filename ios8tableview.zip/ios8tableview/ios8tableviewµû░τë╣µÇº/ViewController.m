//
//  ViewController.m
//  ios8tableview新特性
//
//  Created by admin on 16/6/6.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "ViewController.h"
#import "TableViewCell.h"

@interface ViewController () <UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tableview;

@property (nonatomic,strong) NSMutableArray  * dataArray;

@end

@implementation ViewController

- (NSMutableArray *)dataArray
{
    if (!_dataArray) {
        _dataArray = [NSMutableArray arrayWithObjects:@"对于UILabel 来说还需要把numberOfLines置为0",
                      @"然后设置UITableView的必要属性",
                      @"然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性",
                      @"wefdscv",
                      @"然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性然后设置UITableView的必要属性",nil];
        
    }
    return _dataArray;
}

/**
 *  ios 新功能 self size cell
 
 我们不再需要为了自适应文字，去计算每个cell 中文字所需要的高度。
 而且有更高的性能。(因为UITableView每次reloadData的时候都会重新计算 cell 的高度，意味着如果有1万个 cell 要展示，需要 调用heightForRowAtIndexPath一万次，这效率是特别低的)
 
 使用方法：
 为UITableViewCell添加约束
 设置UITableView 的estimatedRowHeight属性
 设置 rowHeight为 UITableViewAutomaticDimension
 有一点需要注意，代码中不能实现heightForRowAtIndexPath 这个方法
 添加约束，有一个原则是，除了自适应text的高度不需要约束外，需要确定所有必要约束
 对于UILabel 来说还需要把numberOfLines置为0
 */

- (void)viewDidLoad {
    [super viewDidLoad];

    [self.tableview registerNib:[UINib nibWithNibName:@"TableViewCell" bundle:nil] forCellReuseIdentifier:@"TableViewCell"];
    
    self.tableview.estimatedRowHeight = 200;
    self.tableview.rowHeight = UITableViewAutomaticDimension;
    
    [self.tableview reloadData];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TableViewCell"];
    
    cell.label.text = self.dataArray[indexPath.row];
    
    return cell;
}



@end
