//
//  TableViewCell.m
//  ios8tableview新特性
//
//  Created by admin on 16/6/6.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "TableViewCell.h"

@implementation TableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
